import {render} from "react-dom";

import "antd-mobile/dist/antd-mobile.css";
import "antd/dist/antd.css";
import "./style/base.less";
import { AppRouter } from "./AppRoute";
import "./style/Font/iconfont.css";

render(<AppRouter></AppRouter>,document.getElementById("app"))