import {Link} from "react-router-dom";
import "./index.less";

export class HomeList extends React.Component {
    constructor(props){
        super(props)
    }
    render(){
            let domList = this.props.list.map((item,i)=>{
                return (
                    <div key={item._id} className="smallcake">
                        <Link to={`/detail/${item._id}`}>
                            <img src={item.img}/>
                            <p><span>{item.name}</span><span className="priceSpan">{item.price.toFixed(2)}/元</span></p>
                        </Link>
                    </div>
                )
            })
        return (
            <div className="cakeBox">
                {domList}
            </div>
        )
    }
}