import {Icon} from "antd";
import {NavLink} from "react-router-dom";
import "./index.less";
export class FooterTabs extends React.Component{
    constructor(props){
        super(props)
        this.state = {
            list:[
                {name:"首页",path:"/home",icon:"home"},
                {name:"分类",path:"/goods",icon:"appstore-o"},
                {name:"购物车",path:"/shopcar",icon:"shopping-cart"},
                {name:"活动",path:"/communty",icon:"team"},
                {name:"我",path:"/user",icon:"user"}
            ]
        }
    }
    render(){
        let domList = this.state.list.map(({name,path,icon})=>{
            return (
                <NavLink
                activeClassName = "active"
                to={path}
                key={path}
                >
                <span className="spanType"><Icon type={icon}/></span>
                <span>{name}</span>
                </NavLink>
            )
        })
        return (
           <nav>
               {domList}
           </nav>
        )
    }
}