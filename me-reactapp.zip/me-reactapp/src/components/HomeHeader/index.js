import { Icon } from "antd";
import {Link} from "react-router-dom";
import "./index.less"
export class HomeHeader extends React.Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <div className="headerBox">
                <h1> 
                    <img src="http://newimgcdn.lapetit.cn/web/images/temporary/plum_blossom.png" alt="" className="img1"/>
                    <img src="http://newimgcdn.lapetit.cn/web/images/logo_new.png" alt="" className="img2" />
                </h1>
                <span className="iconSearch">
                    <Link to={"/goods"}>
                        <Icon type="search" style={{color:"#d0d000"}} />
                    </Link>
                </span>
            </div>
        )
    }
}