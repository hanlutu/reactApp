import { Carousel} from 'antd-mobile';
import {Link} from "react-router-dom";
import "./index.less"
export class Banner extends React.Component{
    constructor(props){
        super(props)
    }
    render(){
        let domList = this.props.list.map((item,i)=>{
            return (
               <div key={item.goodsID} className="bannerBox">
                    <Link to={`/detail/${item.goodsID}`}>
                        <img src={item.banner} alt=""/>
                    </Link>
               </div>
            )
        })
        return (
            <Carousel
                autoplay
                infinite
            >
                {domList}
            </Carousel>
        )
    }
}