import {Icon, ActionSheet, Button, Toast} from "antd-mobile";
import "./index.less";

const isIPhone = new RegExp('\\biPhone\\b|\\biPod\\b', 'i').test(window.navigator.userAgent);
let wrapProps;
if (isIPhone) {
  wrapProps = {
    onTouchStart: e => e.preventDefault(),
  };
}

const iconList = [
  { icon: <img src="https://zos.alipayobjects.com/rmsportal/WmEzpOsElbbvgmrexFSH.png" />, title: '发送给朋友' },
  { icon: <img src="https://zos.alipayobjects.com/rmsportal/HssPJKvrjEByyVWJIFwl.png" />, title: '新浪微博' },
  { icon: <img src="https://zos.alipayobjects.com/rmsportal/HCGowLrLFMFglxRAKjWd.png" />, title: '生活圈' },
  { icon: <img src="https://zos.alipayobjects.com/rmsportal/LeZNKxCTkLHDWsjFfqqn.png" />, title: '微信好友' },
  { icon: <img src="https://zos.alipayobjects.com/rmsportal/YHHFcpGxlvQIqCAvZdbw.png" />, title: 'QQ' },
];


export class GoodsHeader extends React.Component{
    constructor(props){
        super(props)
        this.state = {
            clicked: 'none',
            clicked1: 'none',
            clicked2: 'none',
          };
    }
    goBack(){
        this.props.history.goBack(-1);
    }
    showShareActionSheet = () => {
        const icons = [...iconList];
        icons.length = 4;
        ActionSheet.showShareActionSheetWithOptions({
          options: icons,
          message: '分享',
          className: 'my-action-sheet',
        },
        (buttonIndex) => {
          this.setState({ clicked1: buttonIndex > -1 ? icons[buttonIndex].title : 'cancel' });
          // also support Promise
          return new Promise((resolve) => {
            Toast.info('1000ms 后关闭');
            setTimeout(resolve, 1000);
          });
        });
      }
   render(){
       return (
           <div className="headgoback">
               <span onClick={this.goBack.bind(this)} className="backIcon"><Icon type="left" />返回</span>
               <span className="logoIcon"><img src="http://newimgcdn.lapetit.cn/web/images/logo_new.png"/></span>
               <span className="fenx"  onClick={this.showShareActionSheet}>
                    <Icon type="ellipsis" />
               </span>
           </div>
       )
   }
}