import { HOME_INIT } from "../actionCreators/actionType";


export let home = (state={
    banner:[],
    cakeList:[],
    toastList:[]
},action)=>{
    let newState = {...state}
    switch (action.type) {
        case HOME_INIT:
            delete action.type
            newState = {...action}
            return newState
            break;
    
        default:
            return state
            break;
    }
}