import { GOODS_INIT } from "../actionCreators/actionType";

export let goods = (state={
    list:[],
    count:0,
    page:1,
    pageSize:6,
    changeTast:"all",
    sortValue:0,
    searchValue:""
},action)=>{
    let newState = {...state}
    switch (action.type) {
        case GOODS_INIT:
            delete action.type
            newState = {...action}
            return newState
            break;
    
        default:
            return state
            break;
    }
}