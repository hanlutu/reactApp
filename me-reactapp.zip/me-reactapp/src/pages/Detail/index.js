import { connect } from "react-redux";
import { GoodsHeader } from "../../components/GoodsHeader";
import { Link } from "react-router-dom";
import { Icon } from "antd"
import { Carousel, Stepper, Toast } from 'antd-mobile';
import { getDetail } from "../../actionCreators/actions";
import "./index.less"


class UI extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            num: 1
        }
    }
    componentDidMount() {
        this.props.getData()
    }
    getNum = (val) => {
        this.setState({
            num: val
        })
        // console.log(val)

    }
    render() {
        let { goods } = this.props;

        let imgList = goods == null ? [] : goods.banner.map((src, i) =>
            <div key={i}>
                <img src={src} alt="" />
            </div>
        )

        let img1List = goods == null ? [] : goods.imgs.slice(1, goods.imgs.length).map((src, i) =>
            <div key={i}>
                <img src={src} alt="" />
            </div>
        )

        let mainDom = goods == null ? [] : (
            <div className="bigBox">
                <header>
                    <GoodsHeader history={this.props.history} />
                </header>
                <section>
                    <div className="Scarousel">
                        <Carousel
                            autoplay
                            infinite
                        >
                            {imgList}
                        </Carousel>
                    </div>
                    <div className="d-content">
                        <h3>{goods.name}</h3>
                        <p className="d-test">口味:{goods.type.value}</p>
                        <div className="d-price">
                            <span>￥{goods.price.toFixed(2)}</span>
                            <del>原价:￥{(goods.price / goods.discount * 10).toFixed(2)}</del>
                        </div>
                        <div className="d-num">数量：
                            <Stepper
                                showNumber
                                max={100}
                                min={1}
                                value={this.state.num}
                                onChange={this.getNum}
                            />
                        </div>
                    </div>
                    <div className="dMsg">
                        <span><Icon type="smile-o" />提前8小时预定</span>
                        <span><Icon type="heart-o" />成为会员优惠多多哦</span>
                        <p><i></i><span>标配餐具x15份,生日蜡烛x1支</span></p>
                    </div>
                    <div className="activeMsg .cl">
                        <span className="cxtex">促销</span>
                        <ul>
                            <li><span>换购</span>买蛋糕可参加优惠换购</li>
                            <li><span>赠品</span>满428赠专享礼包1个</li>
                            <li><span>赠品</span>满328赠新年红包</li>
                        </ul>
                    </div>

                    <h2>商品详情</h2>
                    <div className="d-main">
                        <h4>寻找心中的美味</h4>
                        <div>
                            <img src={goods.imgs[0]} />
                        </div>
                        <h5>{goods.detail}</h5>
                        {img1List}
                    </div>
                </section>
                <footer className="detail-footer">
                    <Link to={"/shopCar"} className="dshop">
                        <Icon type="shopping-cart" />
                        <span>购物车</span>
                    </Link>
                    <span className="dshop">
                        <Icon type="customer-service" />
                        <span>客服</span>
                    </span>
                    <div className='d-shop'>
                        <button className="btnd">立即购买</button>
                        <button className="btnd" onClick={this.props.addCar.bind(this)}>加入购物车</button>
                    </div>
                </footer>
            </div>
        )
        return mainDom
    }
}

let mstp = ({ detail }) => detail

let mdtp = (dispatch, props) => ({
    getData() {
        let { goodsid } = props.match.params;
        // console.log(goodsid)
        dispatch(getDetail(goodsid))
    },
    addCar() {
        let goodsInfo = this.props.goods
        let number = this.state.num
        let goodsList = []
        let flag = false
        let username = sessionStorage.getItem("username")
        if (username != null) {
            let goodsObj = {
                username: username,
                goodsid: goodsInfo._id,
                name: goodsInfo.name,
                price: goodsInfo.price,
                num: number,
                img: goodsInfo.img
            }
            let shopCars = localStorage.getItem("shopCars");
            shopCars = JSON.parse(shopCars);

            if (shopCars == null) {
                goodsList.push(goodsObj)
            } else {
                shopCars.push(goodsObj)
                goodsList = shopCars
                let newList = goodsList.filter(item => {
                    return item.username == username
                })
                // console.log(newList)
                let otherObj = goodsList.filter(item => {
                    return item.username != username
                })
                let newNum = 0
                let other = newList.filter(item=>{
                    return item.goodsid != goodsObj.goodsid
                })
                console.log(other)
                for(var i =0 ;i<newList.length;i++){
                    if(newList[i].goodsid == goodsObj.goodsid){
                        let arr = newList[i];
                        newNum += arr.num
                    }
                }
                goodsObj.num =newNum
                let list = other.concat(goodsObj)
                shopCars = otherObj.concat(list)
                goodsList = shopCars

                // newList.map(function (item) {
                //     if (item.goodsid == goodsObj.goodsid) {
                //         console.log(item)//看是否是同一件商品 如果是同一件商品就更新
                //         item.num += goodsObj.num;
                //         flag = true;
                //     } else {
                //         flag = false
                //     }
                // })
                // if (!flag) {//如果商品不存在就新增
                //     // shopCars.push(goodsObj)
                //     shopCars = otherObj.concat(newList)
                //     console.log(shopCars)
                //     goodsList = shopCars;
                // } else {//如果存在的话 更新
                //     // console.log(goodsList)
                //     shopCars = otherObj.concat(newList)
                //     goodsList = shopCars;
                //     // goodsList = shopCars;
                // }



            }
            localStorage.setItem("shopCars", JSON.stringify(goodsList));
            successToast();
        } else {
            let timer = setTimeout(() => {
                this.props.history.push({ pathname: "/login" })
                clearTimeout(timer)
            }, 1000)
        }

    }
    //     shopCars.push(goodsObj)
    //     goodsList = shopCars 
    // //     console.log(goodsList)
    // //     goodsList = goodsList.filter(item=>{
    // //          return item.username == username
    // //     })
    // //     // console.log(goodsList)

    // //    console.log(otherObj)
    //     if(goodsList.length > 0){
    //         goodsList = goodsList.filter(item=>{
    //             return item.username == username
    //        })
    //         let  otherObj = goodsList.filter(item=>{
    //         return item.username != username
    //    })
    //         // let newObj = goodsList.filter(item=>{
    //         //     return item.goodsid == goodsInfo._id
    //         // })
    //         // // let otherObj = goodsList.filter( item=> {
    //         // //     return item.goodsid != goodsInfo._id
    //         // // })
    //         goodsList.map(function(item){
    //             if(item.goodsid == goodsObj.goodsid){
    //                 console.log(item)//看是否是同一件商品 如果是同一件商品就更新
    //                 item.num += goodsObj.num;
    //                 flag = true;
    //             }else{
    //                 flag=false
    //             }
    //     })
    //         if(!flag){//如果商品不存在就新增
    //             shopCars.push(goodsObj)
    //             console.log(shopCars)
    //             // goodsList = shopCars;
    //         }else{//如果存在的话 更新
    //             console.log(goodsList)
    //             // goodsList = shopCars;
    //         }

    //     let newNum = 0
    //     for (let i = 0; i < newObj.length; i++) {
    //         let arr = newObj[i];
    //         // console.log(arr)
    //         newNum += arr.num
    //     }
    //     goodsObj.num = newNum
    //     console.log(goodsObj)
    //     shopCars = otherObj.concat(goodsObj)
    //     console.log(shopCars)
    //     goodsList = shopCars
    //     console.log(goodsList)
    // }

    // shopCars.map(function(item){
    //     if(item.goodsid == goodsInfo._id){
    //         // console.log(item)//看是否是同一件商品 如果是同一件商品就更新
    //         item.num += goodsObj.num;
    //         flag = true;
    //     }else{
    //         flag=false
    //     }
    // })
    // // console.log(shopCars)
    // if(!flag){//如果商品不存在就新增
    //     shopCars.push(goodsObj)
    //     goodsList = shopCars;
    // }else{//如果存在的话 更新
    //     console.log(shopCars)
    //     goodsList = shopCars;
    // }

    // }else{
    //     goodsList.push(goodsObj)
    // }
    // localStorage.setItem("shopCars", JSON.stringify(goodsList));
    // successToast();


})


function successToast() { //加入购物车成功的提示
    Toast.success('已成功加入您的购物车', 1.5);
}
export let Detail = connect(mstp, mdtp)(UI)