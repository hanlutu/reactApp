import { connect } from "react-redux";
import { Icon, Button } from "antd";
import { Link } from "react-router-dom";
import { FooterTabs } from "../../components/FooterTabs";
import "./index.less";

let username = sessionStorage.getItem("username")
let shopcarList = JSON.parse(localStorage.getItem("shopCars"))

let otherArray = []
if (shopcarList != null) {
    otherArray = shopcarList.filter(item => {
        return username != item.username;
    })
}

// let newArray = shopcarList.filter(item => {
//     return username == item.username;
// })


class UI extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            username: "",
            isLogin: false,
            goodsList: null,
            num: 0,
            allPrice: 0,
        }
        this.checkAll = this.checkAll.bind(this);
        this.delOne = this.delOne.bind(this);
        this.delAll = this.delAll.bind(this);
    }
    componentDidMount() {
        // window.location.reload();
        this.props.shopInit.bind(this)();
    }

    goBack() {
        this.props.history.goBack(-1);
    }
    goHome() {
        this.props.history.push({ pathname: "/home" })
    }
    checkOne() {//单选
        let count = 0;
        let allPrice = 0;
        this.state.goodsList.forEach((item, index) => {
            if (this.refs[index].checked) { //选中状态
                count++;//计数选中一个加1
                allPrice += item.price * item.num;
            }
        });
        // allPrice = allPrice.toFixed(2);
        this.setState({
            allPrice: allPrice
        })
        if (this.state.goodsList.length == count) {//全部选中
            this.refs.checkall.checked = true;
        } else {
            this.refs.checkall.checked = false;
        }
    }
    checkAll() {//全选
        if (this.refs.checkall.checked == true) {//全选被选中的话
            this.state.goodsList.forEach((item, index) => {
                this.refs[index].checked = true;//每个单选就是选中状态
                this.checkOne();
            });
        } else {
            this.state.goodsList.forEach((item, index) => {
                this.refs[index].checked = false;
                this.checkOne();
            });
        }

    }
    delOne(index) {//单个删除
        this.state.goodsList.splice(index, 1);//截取当前下标1个数组
        this.forceUpdate();
        let arr = []
        arr = otherArray.concat(this.state.goodsList)
        localStorage.setItem("shopCars", JSON.stringify(arr))
        window.location.reload();

    }
    delAll() {//批量删除
        let goodsList = this.state.goodsList.filter((item, index) => {//筛选出没有被选中状态的
            if (!this.refs[index].checked) {
                return item
            }
        });
        // console.log(goodsList)
        this.setState({
            goodsList: goodsList
        })
        let arr = []
        arr = otherArray.concat(goodsList)
        localStorage.setItem("shopCars", JSON.stringify(arr))
        this.forceUpdate();//强制更新
        window.location.reload();
    }
    changeNum(index, isAdd = true) {
        return (
            function () {
                isAdd ? this.state.goodsList[index].num++ : this.state.goodsList[index].num--;
                if (this.state.goodsList[index].num <= 1) {
                    this.state.goodsList[index].num = 1;
                }
                this.forceUpdate();
                this.checkOne();
                let arr = [];
                arr = otherArray.concat(this.state.goodsList)
                localStorage.setItem("shopCars", JSON.stringify(arr))
            }

        ).bind(this)

    }
    handWrite(index) {
        return (function (e) {
            this.state.goodsList[index].num = e.target.value * 1;
            this.forceUpdate();//强制更新
        }).bind(this)
    }
    render() {
        let goodsList = this.state.goodsList == null ? null : this.state.goodsList.map(({ goodsid, img, name, num, price }, index) => {
            return (
                <div className="topBox" key={goodsid}>
                    <div className="mainBox cl" >
                        <div className="gl">
                            <input
                                className="oInput"
                                id={goodsid}
                                type="checkbox"
                                ref={index}
                                onClick={() => this.checkOne(index)}
                            />
                            <label htmlFor={goodsid}></label>
                            <img src={img} alt="" />
                        </div>
                        <div className="gr">
                            <p>
                                <Link to={`/detail/${goodsid}`}>
                                    <span className="goodsName">{name}</span>
                                </Link>
                                <Icon type="delete" className="dIcon" onClick={() => this.delOne(index)} />
                            </p>
                            <div className="numOperat">
                                <span>￥{price}</span>
                                <div>
                                    <button onClick={this.changeNum(index, false)}>-</button>
                                    <input type="number" onChange={this.handWrite(index)} value={num} />
                                    <button onClick={this.changeNum(index)} >+</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )
        })
        let sectionDom = !this.state.isLogin ? (<div className="emptyList">
            <img src="https://newimgcdn.lapetit.cn/h5/images/shopping/empty.png" />
            <h3>您还没有选购您的商品</h3>
        </div>) : (<div>
            {goodsList}
            <div className="checkBox">
                <div className="checkAllList">
                    <input
                        id="qInput"
                        ref="checkall"
                        type="checkbox"
                        onClick={() => this.checkAll()
                        }
                    />
                    <label htmlFor="qInput"></label>
                    全选
                </div>
                <div className="sDel" onClick={this.delAll}>删除</div>
                <div className="sCount">
                    <p className="sum">合计:<span>{this.state.allPrice.toFixed(2)}</span></p>
                    <p className="yf">(不含运费)</p>
                </div>
                <div className="settlement">
                    <button >结算</button>
                </div>
            </div>
        </div>)

        return (
            <div className="bigBox shopCarBox">
                <header>
                    <h1>购物车</h1>
                    <div className="leftIcon">
                        <Icon type="left" onClick={this.goBack.bind(this)} />
                    </div>
                    <div className="rightIcon">
                        <Icon type="home" onClick={this.goHome.bind(this)} />
                    </div>
                </header>
                <section>
                    {sectionDom}
                </section>
                <footer>
                    <FooterTabs />
                </footer>
            </div>
        )
    }
}
let mstp = ({ goods }) => goods;

let mdtp = dispatch => ({
    shopInit() {
        let username = sessionStorage.getItem("username")
        if (username != null) {
            let goodsList = localStorage.getItem("shopCars");
            goodsList = JSON.parse(goodsList);
            // console.log(goodsList)
            if (goodsList == null) return;
            let newArray = goodsList.filter(item => {
                return username == item.username;
            })
            // console.log(goodsList)
            if (newArray.length > 0) {  //已登录并且已选购商品状态
                // goodsList = goodsList.filter(item => {
                //     return username == item.username;
                // })
                this.setState({
                    isLogin: true,
                    goodsList: newArray.map(function (item) {//先循环集合里面所有的对象，然后逐一添加上选中属性
                        item.checked = false;
                        return item
                    })
                })

            } else {//用户已经登陆但是未选购商品状态
                this.setState({
                    isLogin: false
                })
            }
        } else {//顾客未登陆状态
            this.setState({
                isLogin: false
            })
        }

    }
})
export let ShopCar = connect(mstp, mdtp)(UI)