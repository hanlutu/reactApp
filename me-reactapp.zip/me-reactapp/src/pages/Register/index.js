import { connect } from "react-redux";
import "./index.less";
import { Icon } from "antd";
import { Link } from "react-router-dom";

class UI extends React.Component {
    constructor(props) {
        super(props)
        this.state={
            username_span:"",
            userpwd_span:"",
            flag1: false,
            flag2: false,
            isRed:true,
            isRed2 : true
        }
    }
    render() {
        return (
            <div className="bigBox">
                <header>
                    <h1>注册</h1>
                    <div className="homeIcon">
                        <Link to={"/home"} >
                            <Icon type="home" className="icon1" />
                        </Link>
                    </div>
                </header>
                <section>
                    <form className="regisReg"  onSubmit={this.props.submit.bind(this)}>
                        <div className="inputText">
                            <Icon type="user" className="iconInput" />
                            <input type="text" placeholder="请输入手机号码" ref="un" onChange={this.props.testName.bind(this)}/>
                        </div>
                        <p className="logMsg"><span style={{color:(this.state.isRed == true) ? "red" : "green"}}>{this.state.username_span}</span></p>
                        <div className="inputText">
                            <Icon type="lock" className="iconInput" />
                            <input type="password" placeholder="输入密码由4到12位的字母，数字组成" ref="pwd1" onChange={this.props.testPwd.bind(this)}/>
                        </div>
                        <div className="inputText">
                            <Icon type="lock" className="iconInput" />
                            <input type="password" placeholder="请再次确认密码" ref="pwd2" onChange={this.props.testPwd.bind(this)} />
                        </div>
                        <p className="logMsg"><span style={{color:(this.state.isRed2 == true) ? "red" : "green"}}>{this.state.userpwd_span}</span></p>
                        <div className="logBtn">
                            <input type="submit" value="注册" />
                        </div>
                        <div>
                            <p>已经有账号？立即<Link to={"/login"} className="goreg">登录</Link></p>
                        </div>
                    </form>
                </section>
            </div>
        )
    }
}

let mstp = (state) => ({

})

let mdtp = dispatch=>({
    testName(){
        let username = this.refs.un.value;
        if(username !=""){
            let usernameReg = /^1[3456789][0-9]{9}$/g;
            if(usernameReg.test(username)){
                this.setState({
                    username_span: "√",
                    flag1: true,
                    isRed : false
                })
            }else{
                this.setState({
                    username_span: "手机号码输入格式错误！",
                    isRed : true
                })
            }
        }else{
            this.setState({
                username_span:"输入内容不能为空！",
                isRed:true
            })
        }
    },
    testPwd(){
        let userpwd1 = this.refs.pwd1.value;
        let userpwd2 = this.refs.pwd2.value;
        if( userpwd2 !== ""){
            if(userpwd1 == userpwd2){
                let  userpwdReg = /^[a-z0-9]{4,12}$/ig;
                if (userpwdReg.test(userpwd2)){
                    var numReg = /[0-9]/g;
                    var numCount = numReg.test(userpwd2) ? 1 : 0;
                    var upperReg = /[A-Z]/g;
                    var upperCount = upperReg.test(userpwd2) ? 1 : 0;
                    var lowerReg = /[a-z]/g;
                    var lowerCount = lowerReg.test(userpwd2) ? 1 : 0;
                    var count = numCount + upperCount + lowerCount;
                    switch (count) {
                        case 1:
                            this.setState({
                                userpwd_span: "密码强度弱",
                                isRed2 : false
                            })
                            break;
                        case 2:
                            this.setState({
                                userpwd_span: "密码强度中",
                                isRed2 : false
                            })
                            break;
                        case 3:
                            this.setState({
                                userpwd_span: "密码强度高",
                                isRed2 : false
                            })
                            break;
                    }
                    this.setState({
                        flag2: true,
                        isRed2 : false
                    })

                }else{
                    this.setState({
                        userpwd_span: "密码格式不合法！",
                        isRed2: true
                    })
                }
            }else{
                this.setState({
                    userpwd_span: "密码不一致！",
                    isRed2 : true
                })
            }

        }else{
            this.setState({
                userpwd_span: "密码不能为空！",
                isRed2: true
            })
        }

    },
    submit(e){
        e.preventDefault();
        if (this.state.flag1 && this.state.flag2){
            let obj = {
                username : this.refs.un.value,
                userpwd : this.refs.pwd1.value
            }

            let list =[]
            let flag = true;
            let userInfo = localStorage.getItem("userInfo")
            if (userInfo != null){
                userInfo = JSON.parse(userInfo);
                userInfo.map(function (item) {
                    let userName = item.username;
                    if (obj.username == userName) {

                        return flag = false;
                    }
                })
                userInfo.push(obj);
                list = userInfo;
            }else{
                list.push(obj)
            }

            if (flag) {
                localStorage.setItem("userInfo", JSON.stringify(list));
                let timer = setTimeout(() => {
                    this.props.history.push('/login')
                    clearTimeout(timer);
                }, 1000)
            } else {
                this.setState({
                    username_span:"",
                    userpwd_span: "用户已存在",
                    isRed2 : true

                })
            }
            
        }
        else {
            this.setState({
                userpwd_span: "账号或密码格式错误！",
                isRed2 : true
            })
        }
    }
})
export let Register = connect(mstp,mdtp)(UI)