import { FooterTabs } from "../../components/FooterTabs";
import { connect } from "react-redux";
import "./index.less";
import { Link } from "react-router-dom";
import { Icon } from "antd";

class UI extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            username: "",
            isLogin: false
        }
    }
    componentDidMount() {
        let username = sessionStorage.getItem("username")
    
        if (username) {
            let newUser = username.substr(0,3)+"****"+username.substr(7)
            this.setState({
                username:newUser,
                isLogin:true
            })
        } else {
            this.setState({
                isLogin: false,
                
            })
        }
    }
    render() {
        let userDom = this.state.isLogin ? <p style={{color:"#a38d6b",fontSize:".3rem"}}>{this.state.username}</p> : <Link to={"/login"}><button>登陆/注册</button></Link>
        return (
            <div className="userBox bigBox">
                <header>
                    <div>
                        <img src="https://newimgcdn.lapetit.cn/h5//images/customer/avatar.png" alt="" />
                    </div>
                    <div>
                        {userDom}
                    </div>
                </header>
                <section>
                    <ul className="orderInfo">
                        <li>
                            <i className="iconfont icon-daifukuan"></i>
                            <span>待付款</span>
                        </li>
                        <li>
                            <i className="iconfont icon-weibiaoti2fuzhi05"></i>
                            <span>待发货</span>
                        </li>
                        <li>
                            <i className="iconfont icon-daishouhuo"></i>
                            <span>待收货</span>
                        </li>
                        <li>
                            <i className="iconfont icon-yduiwodedingdan"></i>
                            <span>我的订单</span>
                        </li>
                    </ul>
                    <ol>
                        <li>
                            <Icon type="tags-o" className="icon1" />
                            <span>优惠券/蛋糕券</span>
                            <Icon type="right" className="icon2" />
                        </li>
                        <li>
                            <Icon type="credit-card" className="icon1" />
                            <span>储值卡</span>
                            <Icon type="right" className="icon2" />
                        </li>
                        <li>
                            <Icon type="gift" className="icon1" />
                            <span>Leclub</span>
                            <Icon type="right" className="icon2" />
                        </li>
                    </ol>
                    <dl>
                        <dd>
                            <span>关于我们</span>
                            <Icon type="right" className="icon2" />
                        </dd>
                        <dd>
                            <span>关于发票</span>
                            <Icon type="right" className="icon2" />
                        </dd>
                    </dl>
                    <div>
                        <button onClick={this.props.exit.bind(this)}>退出登录</button>
                    </div>
                </section>
                <footer>
                    <FooterTabs />
                </footer>
            </div>
        )
    }
}

let mdst = dispatch =>({
    exit(){
        let username = sessionStorage.getItem("username")
        let array = JSON.parse(localStorage.getItem("userInfo"))
        if(username){
            let array1 = array.filter(function (item) {
                return item.username == username
            })
            if (array1[0].Flag != "") {
                array1[0].Flag = ""
                let array2 = array.filter(function (item) {
                    return item.username != username
                })
                let newArray = array2.concat(array1)
                localStorage.setItem("userInfo", JSON.stringify(newArray))
                sessionStorage.removeItem("username")
                window.location.reload()
            }
        }
    }
})

export let User = connect(mdst)(UI)