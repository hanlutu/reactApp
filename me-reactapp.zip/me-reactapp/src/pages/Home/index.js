import { FooterTabs } from "../../components/FooterTabs";
import { HomeHeader } from "../../components/HomeHeader";
import { connect } from "react-redux";
import { Banner } from "../../components/Banner";
import { getHomeList } from "../../actionCreators/actions";
import { NoticeBar, WhiteSpace, Icon } from 'antd-mobile';
import {HomeList} from "../../components/HomeList";

import "./index.less";

class UI extends React.Component {
    constructor(props) {
        super(props)
    }
    componentDidMount() {
        this.props.getData()
    }
    render() {
        return (
            <div className="bigBox">
                <header>
                    <HomeHeader />
                </header>
                <section>
                    <Banner list={this.props.banner} />
                    <div>
                        <NoticeBar marqueeProps={{ loop: true, style: { padding: '0 7.5px' } }} mode="closable">
                            温馨提示：2019年2月4日当天最晚配送时间为下午18：00，给您带来不便，还望见谅！
                        </NoticeBar>
                    </div>
                    <div className="cakeTle">
                        <i className="icon1"></i>
                        <span>蛋糕</span>
                        <i className="icon2"></i>
                    </div>
                    <HomeList list={this.props.cakeList} />
                    <div className="cakeTle">
                        <i className="icon3"></i>
                        <span>吐司</span>
                        <i className="icon4"></i>
                    </div>
                    <HomeList list={this.props.toastList} />
                    <div className="videoBox">
                        <h3>
                            <img src="https://act.mcake.com/fangli/2019/pc/qingrenjie/images/section-3-title.png"/>
                        </h3>
                        <div>
                            <video preload="auto" controls="controls" autoPlay="autoplay" loop="loop" poster="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/videoImg.jpg">
                                <source src="https://act.mcake.com/fangli/2019/pc/qingrenjie/video/video.mp4" type="video/mp4"/>
                            </video>
                        </div>
                    </div>
                    <div className="fotericon">
                        <p><span>没了。</span><i></i></p>
                    </div>
                </section>
                <footer>
                    <FooterTabs />
                </footer>
            </div>
        )
    }
}

let mapStateToProps = ({ home }) => home;

let mapDispathToProps = dispatch => ({
    getData() {
        dispatch(getHomeList())
    }
})

export let Home = connect(mapStateToProps, mapDispathToProps)(UI)