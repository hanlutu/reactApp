import { FooterTabs } from "../../components/FooterTabs";
import { connect } from "react-redux";
import { GoodsHeader } from "../../components/GoodsHeader";
import { SearchBar, WhiteSpace, WingBlank, Pagination } from 'antd-mobile';
import { Icon } from "antd";
import "./index.less";
// import {NavLink} from "react-router-dom";
import { getGoodsDate } from "../../actionCreators/actions";
import { HomeList } from "../../components/HomeList";

let tasteList = [
    { text: "全部口味", value: "all" },
    { text: "雪域口味", value: "snowy" },
    { text: "慕斯口味", value: "mousse" },
    { text: "鲜果口味", value: "fruit" },
    { text: "芝士口味", value: "cheese" }
]
let sortList = [
    { text: "价格由低到高", value: 1, type: "arrow-up" },
    { text: "价格由高到低", value: -1, type: "arrow-down" }
]

class UI extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            bgColor: 0,
            colors : null
        };
        this.getList = this.getList.bind(this)
    }
    componentDidMount() {
        let { page, pageSize, changeTast, sortValue, searchValue } = this.props
        this.props.getData(page, pageSize, changeTast, sortValue, searchValue)
    }
    searchBy = (value) => {
        // // console.log(value)
        let searchValue = value
        let { page, pageSize, changeTast, sortValue } = this.props
        this.props.getData(page, pageSize, changeTast, sortValue, searchValue)
    }
    sortBy = (value, index) => {
        this.setState({
            colors:index
        })
        let sortValue = value
        let { page, pageSize, changeTast, searchValue } = this.props
        this.props.getData(page, pageSize, changeTast, sortValue, searchValue)
    }

    changeValue = (value, index) => {
        this.setState({
            bgColor: index,
            colors:null
        })
        let changeTast = value
        let { page, pageSize, sortValue=0, searchValue } = this.props
        this.props.getData(page = 1, pageSize, changeTast, sortValue, searchValue)
    }
    getList(page) {
        // console.log(page)
        let { pageSize, changeTast, sortValue, searchValue } = this.props
        // console.log(sortValue)
        this.props.getData(page, pageSize, changeTast, sortValue, searchValue)

    }
    render() {
        let domTaste = tasteList.map((item, i) => {
            return (
                <ul key={i}>
                    <li onClick={(e) => this.changeValue(item.value, i)} className={this.state.bgColor == i ? "active" : null}>{item.text}</li>
                </ul>
            )
        })

        let domSort = sortList.map((item, i) => {
            return (
                <span className="sortD" onClick={(e) => this.sortBy(item.value, i)} key={i} className={this.state.colors == i ? "aactive" : null}>{item.text}<Icon type={item.type} /></span>
                // <span className="sortA" onClick={(e) => this.sortD("desc")}>价格从高到低<Icon type="arrow-down" /></span>
            )
        })
        let domList = this.props.list.length == 0 ? <div className="listEmpty">暂时此商品,敬请期待</div>:(
            <div>
                <HomeList list={this.props.list} />
                        <Pagination
                            total={this.props.count}
                            className="custom-pagination-with-icon"
                            current={this.props.page}
                            locale={{
                                prevText: (<span className="arrow-align">上一页</span>),
                                nextText: (<span className="arrow-align">下一页</span>),
                            }}
                            onChange={this.getList}
                        />
            </div>
        )
        return (
            <div className="bigBox">
                <header>
                    <GoodsHeader history={this.props.history} />
                </header>
                <section>
                    <div className="searchList">
                        <WingBlank><div className="sub-title"></div></WingBlank>
                        <SearchBar
                            placeholder="按蛋糕名搜索"
                            maxLength={8}
                            onChange={this.searchBy.bind(this)}
                        />
                        <WhiteSpace />
                    </div>
                    <div className="filterBox">
                        <span>口味：</span>
                        {domTaste}
                    </div>
                    <div className="sortBy"> {domSort}</div>
                    <div>
                        {domList}
                    </div>

                </section>
                <footer>
                    <FooterTabs />
                </footer>
            </div>
        )
    }
}

let mstp = ({ goods }) => goods

let mdtp = dispatch => ({
    getData(page, pageSize, changeTast, sortValue, searchValue) {
        dispatch(getGoodsDate(page, pageSize, changeTast, sortValue, searchValue))
    }
})

export let Goods = connect(mstp, mdtp)(UI)