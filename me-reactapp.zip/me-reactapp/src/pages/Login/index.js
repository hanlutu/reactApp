import { connect } from "react-redux";
import "./index.less";
import { Icon } from "antd";
import { Link } from "react-router-dom";

class UI extends React.Component {
    constructor(props) {
        super(props)
        this.state ={
            userpwd_span: "",
            flag: false,
            // flag2: false,
        }
    }
    render() {
        return (
            <div className="bigBox">
                <header>
                    <h1>登录</h1>
                    <div className="homeIcon">
                        <Link to={"/home"} >
                            <Icon type="home" className="icon1"/>
                        </Link>
                    </div>
                </header>
                <section>
                        <form className="logReg" onSubmit={this.props.submit.bind(this)} >
                            <div className="inputText">
                                <Icon type="user" className="iconInput"/>
                                <input type="tel" placeholder="请输入手机号码" ref="un" />
                            </div>
                            <div className="inputText">
                                <Icon type="lock" className="iconInput"/>
                                <input type="password" placeholder="请输入密码" ref="up"  />
                            </div>
                            <p className="logMsg"><span style={{ color:"red"}} >{this.state.userpwd_span}</span></p>
                            <div className="logBtn">
                                <input type="submit" value="登录"/>
                            </div>
                            <div>
                                <p>还没有账号？立即<Link to={"/register"} className="goreg">注册</Link></p>
                            </div>
                        </form>
                </section>
                <footer className="lfooter">
                    <h4><span>——————————</span>其他登录方式<span>——————————</span></h4>
                    <div>
                        <img src="https://h5.mcake.com/static/images/icons/alipay.png" alt="支付宝登录"/>
                        <img src="https://h5.mcake.com/static/images/icons/weibo.png" alt="微博登录"/>
                    </div>
                </footer>
            </div>
        )
    }
}

let mdtp = dispatch =>({
    submit(e){
        e.preventDefault();
        let username = this.refs.un.value
        let userpwd = this.refs.up.value
        if(username && userpwd !=""){
            let userList = localStorage.getItem("userInfo");
            userList = JSON.parse(userList) //取出存放在localStorage中的数据
            console.log(userList)
            if(userList != null){
                let newAarry = userList.filter((item) => { //筛选出顾客输入的用户名一致的
                    return item.username == username;
                })
                let otherAarry = userList.filter(item => { //不相等的集合
                    return item.username != username;
                })
                if(newAarry.length !=0 && newAarry[0].userpwd == userpwd){
                    newAarry[0].Flag = "isLogin" //存入一个flag用来判断顾客是否是登陆状态
                    userList = otherAarry.concat(newAarry)
                    localStorage.setItem("userInfo", JSON.stringify(userList))
                    sessionStorage.setItem("username", username)
                    let timer = setTimeout(() => {
                        this.props.history.push({ pathname: `/user/${username}` })
                        clearTimeout(timer);
                    }, 1000);
                }else{
                    // console.log("我触发了")
                    this.setState({
                        userpwd_span:"用户名或者密码输入错误!"
                    })
                }

            }else{
                this.setState({
                    userpwd_span:"用户名或者密码输入错误!"
                })
            }
        }else{
            this.setState({
                userpwd_span:"用户名、密码不为空"
            })
        }
    }
})

export let Login = connect(mdtp)(UI)