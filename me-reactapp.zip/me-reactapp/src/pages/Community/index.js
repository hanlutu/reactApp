import { GoodsHeader } from "../../components/GoodsHeader";
import { Link } from "react-router-dom";
import "./index.less";

export class Community extends React.Component {
    constructor(props) {
        super(props)
        this.state={
            car:"false"
        }
    }
    player() {
        // console.log(this.refs.audio)
        // this.refs.audio.play()
        let audio = this.refs.audio
        if(audio.paused){
            audio.play()
            return;
        }else{
            audio.pause()
        }
    //    this.refs.audio.controls = true
        // this.setState({
        //     car: "true"
        // })
    }
    render() {
        return (
            <div className="activeBox">
                <header>
                    <GoodsHeader history={this.props.history} />
                </header>
                <section>
                    <div className="imgBox">
                        <img src="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/banner-wap.jpg" alt="" />
                    </div>
                    <div className="imgBox1">
                        <img src="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/s-sction-1.png" alt="" />
                    </div>
                    <div className="imgBox2">
                        <img src="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/s-sction-2.png" alt="" className="img1" />
                        <Link to={"/goods"} className="img2">
                            <img src="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/by-btn.png" alt="" />
                        </Link>
                    </div>
                    <div className="imgBox3">
                        <h3>
                            <img src="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/section-3-title.png" alt="" />
                        </h3>
                        <div className="video">
                            <video id="video" preload="auto" controls="controls" loop="loop" poster="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/videoImg.jpg">
                                <source src="https://act.mcake.com/fangli/2019/wap/qingrenjie/video/video.mp4" type="video/mp4" />
                            </video>
                        </div>
                    </div>
                    <div className="imgBox4">
                        <img src="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/s-sction-4.png" alt="" className="img" />
                        <img src="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/piaodai.png" alt="" className="img1" />
                        <div className="audio">
                            <div className="shadowa" onClick={this.player.bind(this)}></div>
                            <audio ref="audio">
                                <source src="https://act.mcake.com/fangli/2019/pc/qingrenjie/video/valentines.mp3" type="audio/mp3" />
                            </audio>
                        </div> 
                    </div>
                    <div className="imgBox5">
                        <img src="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/s-sction-5.png" alt="" />
                    </div>
                    <div className="imgBox6">
                        <div className="fotimg">
                            <img src="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/more-bg.png" alt="" className="bigimg" />
                            <Link to={"/goods"} className="moreimg">
                                <img src="https://act.mcake.com/fangli/2019/wap/qingrenjie/images/more.png" alt="" />
                            </Link>
                        </div>
                        <div className="activeReg">
                            <h4>活动规则:</h4>
                            <p>1、活动时间：2019年1月18日-2019年2月14日</p>
                            <p>2、活动城市：上海、北京、苏州、杭州</p>
                            <p>3、支付方式：微信、支付宝、现金</p>
                            <p>
                                4、活动内容：
                                <br />
                                凡活动期间订购臻爱·约瑟芬有机会获赠what for法式定制LOVE金属手绳，价值：198元，数量有限，赠完即止
                            </p>
                            <p>5、本活动与会员等级制度、积分同享，但不与其他优惠同享</p>
                            <p>6、本活动最终解释权归诺心所有</p>
                        </div>
                    </div>
                </section>
            </div>
        )
    }
}