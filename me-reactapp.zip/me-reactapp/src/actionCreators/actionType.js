export const HOME_INIT = "HOME_INIT";
export const GOODS_INIT = "GOODS_INIT";
export const DETAIL_INIT = "DETAIL_INIT";