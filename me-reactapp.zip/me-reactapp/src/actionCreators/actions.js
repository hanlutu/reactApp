import axios from "axios";
import async from "async";
import { HOME_INIT, GOODS_INIT, DETAIL_INIT } from "./actionType";


export let setHomeList = (banner, cakeList, toastList) => ({
    type: HOME_INIT,
    banner,
    cakeList,
    toastList
})

export let getHomeList = () => {
    return dispatch => {
        async.parallel({
            banner(cb) {
                axios.get("/goodsData/hotgoods.json")
                    .then(({ data }) => {
                        // console.log(data.list)
                        cb(null, data.list)
                    })
            },
            cakeList(cb) {
                axios.get("/goodsData/allgoods.json")
                    .then(({ data }) => {
                        let newList = data.list.filter((item) => {
                            return item.type.value.indexOf("snowy") != -1
                        })
                        cb(null, newList)
                    })
            },
            toastList(cb) {
                axios.get("/goodsData/allgoods.json")
                    .then(({ data }) => {
                        let newList = data.list.filter((item) => {
                            return item.type.value.indexOf("toast") != -1
                        })
                        cb(null, newList)
                    })
            }
        }, (err, { banner, cakeList, toastList }) => {
            dispatch(setHomeList(banner, cakeList, toastList))
        })
    }
}

export let setGoods = (list, count, page, pageSize, changeTast,sortValue,searchValue) => ({
    type: GOODS_INIT,
    list,
    count,
    page,
    pageSize,
    changeTast,
    sortValue,
    searchValue
})

function SortBy(attr, rev) {
    if (rev == undefined) {
        rev = 1;
    } else {
        rev = (rev) ? 1 : -1
    }
    return function (a, b) {
        a = a[attr];
        b = b[attr];
        if (a < b) {
            return rev * -1;
        }
        if (a > b) {
            return rev * 1;
        }
        return 0;
    }
}


export let getGoodsDate = (page = 1, pageSize = 6, changeTast = "all",sortValue=0,searchValue="") => {
    return dispatch => {
        axios.get("/goodsData/allgoods.json").then(({ data }) => {
            let startList = []; 
            console.log(sortValue)
            if(sortValue != 0){
                if(sortValue == -1){
                   
                    data.list.sort(SortBy("price",false))
                }else{
                    data.list.sort(SortBy("price",true))
                }
            }
            if (changeTast != "all") {
                startList = data.list.filter(function (item) {
                    return item.type.value == changeTast
                })
            } else {
                startList = data.list
            }

            let newList = []
            startList.map(function(item){
                if(item.name.indexOf(searchValue) != -1){
                    newList.push(item);
                }
            })
            let count = Math.ceil(newList.length / pageSize);
            if(count > 1){
                newList= newList.slice((page - 1) * pageSize, page * pageSize)
            }else{
                newList = newList
            }
            dispatch(setGoods(newList, count, page, pageSize, changeTast,sortValue))
        })
    }
}

export let setDetail = goods =>({
    type:DETAIL_INIT,
    goods
})

export let getDetail = goodsid => dispatch=>{
    axios.get("/goodsData/allgoods.json").then(({data})=>{
        let newList = {}
        
        data.list.map((item,i)=>{
            if(item._id == goodsid){
                return newList = item
            }
        })
        
        dispatch(setDetail(newList))
    })
}