import { Route, Switch, Redirect } from "react-router-dom";
import {Home} from "./pages/Home";
import {Goods} from "./pages/Goods";
import {ShopCar} from "./pages/ShopCar";
import {Community} from "./pages/Community";
import {User} from "./pages/User";
import {Detail} from "./pages/Detail";
import {Login} from "./pages/Login";
import {Register} from "./pages/Register";


export class Index extends React.Component{
    constructor(props){
        super(props)
    }
    render(){
        return (
            <div className="box">
                <Switch>
                    <Redirect path="/" to={"/home"} exact={true}></Redirect>
                    <Route path={"/home"} component={Home}></Route>
                    <Route path={"/goods"} component={Goods}></Route>
                    <Route path={"/shopcar"} component={ShopCar}></Route>
                    <Route path={"/communty"} component={Community}></Route>
                    <Route path={"/user"} component={User}></Route>
                    <Route path={"/detail/:goodsid"} component={Detail}></Route>
                    <Route path={"/login"} component={Login}></Route>
                    <Route path={"/register"} component={Register}></Route>
                </Switch>
            </div>
        )
    }
}